<?php
# @Date:   2019-12-02T14:02:07+00:00
# @Last modified time: 2019-12-02T14:05:27+00:00




namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserHomeController extends Controller
{
    //
}
 
