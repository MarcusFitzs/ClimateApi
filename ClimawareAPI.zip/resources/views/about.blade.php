@extends('layouts.app')
# @Date:   2019-10-29T22:17:12+00:00
# @Last modified time: 2019-11-04T17:53:18+00:00




@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">About Us</div>

                <div class="card-body">
                    This is the about page
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
