;
# @Date:   2019-11-04T18:46:42+00:00
# @Last  modified time: 2019-11-04T19:15:11+00:00




<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            Articles
            <a href="<?php echo e(route('admin.articles.create')); ?>" class="btn btn-primary float-right">Add</a>
          </div>
          <div class="card-body">
            <?php if(count($articles) === 0): ?>
              <p> There are no articles</p>
            <?php else: ?>
              <table id="table-articles" class="table table-hover">
                <thead>
                  <th>Name</th>
                  <th>Author_Id</th>
                  <th>Title</th>
                  <th>Description</th>
                  <th>URL</th>
                  <!-- <th>UrlToImage</th>
                  <th>PublishedAt</th> -->
                  <th>Actions</th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id="<?php echo e($article->id); ?>">
                      <td><?php echo e($article->name); ?></td>
                      <td><?php echo e($article->author_id); ?></td>
                      <td><?php echo e($article->title); ?></td>
                      <td><?php echo e($article->description); ?></td>
                      <td><?php echo e($article->url); ?></td>
                      <!-- <td><?php echo e($article->urlToImage); ?></td>
                      <td><?php echo e($article->publishedAt); ?></td> -->
                      <td>
                        <a href="<?php echo e(route('admin.articles.show', $article->id)); ?>" class="btn btn-default">View</a>
                        <a href="<?php echo e(route('admin.articles.edit', $article->id)); ?>" class="btn btn-warning">Edit</a>
                        <form style="display:inline-block" method="POST" action="<?php echo e(route('admin.articles.destroy', $article->id)); ?>">
                          <input type="hidden" name="_method" value="DELETE">
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                          <button type="submit" class="form-control btn btn-danger"> Delete</a>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcus\Desktop\Laravel Projects\ClimateAPI\articles-api2\resources\views/admin/articles/index.blade.php ENDPATH**/ ?>