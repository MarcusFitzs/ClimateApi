;
# @Date:   2019-11-04T19:48:33+00:00
# @Last  modified time: 2019-11-04T19:56:15+00:00




<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="card">
          <div class="card-header">
            Article: <?php echo e($article->name); ?>

          </div>
          <div class="card-body">
              <table class="table table-hover">
                <tbody>
                  <tr>
                    <td>Name</td>
                    <td><?php echo e($article->name); ?></td>
                  </tr>
                  <tr>
                    <td>Author's ID</td>
                    <td><?php echo e($article->author_id); ?></td>
                  </tr>
                  <tr>
                    <td>title</td>
                    <td><?php echo e($article->title); ?></td>
                  </tr>
                  <tr>
                    <td>Description</td>
                    <td><?php echo e($article->description); ?></td>
                  </tr>
                  <tr>
                    <td>URL</td>
                    <td><?php echo e($article->url); ?></td>
                  </tr>
                  <!-- <tr>
                    <td>UrlToImage</td>
                    <td><?php echo e($article->UrlToImage); ?></td>
                  </tr>
                  <tr>
                    <td>publishedAt</td>
                    <td><?php echo e($article->publishedAt); ?></td>
                  </tr> -->
                </tbody>
              </table>
              <a href="<?php echo e(route('admin.articles.index')); ?>" class="btn btn-default">Back</a>
              <a href="<?php echo e(route('admin.articles.edit', $article->id)); ?>" class="btn btn-warning">Edit</a>
              <form style="display:inline-block" method="POST" action="<?php echo e(route('admin.articles.destroy', $article->id)); ?>">
                <input type="hidden" name="_method" value="DELETE">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button type="submit" class="form-control btn btn-danger"> Delete</a>
              </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcus\Desktop\Laravel Projects\ClimateAPI\articles-api2\resources\views/admin/articles/show.blade.php ENDPATH**/ ?>